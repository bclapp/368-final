import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.applet.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageObserver;

import javax.swing.*;
import javax.swing.border.LineBorder;
public class TicClient implements Runnable,ActionListener{
	
   
   private static JFrame area = new JFrame("Tic-Tac");
   private static JPanel window = new JPanel();
   private JButton a = new JButton("");
   private JButton b = new JButton("");
   private JButton c = new JButton(""); 
   private JButton d = new JButton("");
   private JButton e = new JButton("");
   private JButton f = new JButton("");
   private JButton g = new JButton("");
   private JButton h = new JButton("");
   private JButton i = new JButton("");
   private JPanel messages = new JPanel();
   private static JLabel messageArea = new JLabel("");
   public static TicClient clientA = new TicClient();
   private static String mark; 
	
   public String player = "";
   private boolean win = false;
	
   private static Socket cSock = null;
   private static PrintStream out;
   private static DataInputStream in;
   private static boolean closed = false;
   private static String opmark;
   private static int count=0;
	   
   public static void main(String[] args){
      Scanner kb = new Scanner(System.in);
      int port;
      
      String host= "localhost";
      port= 8080;
      //System.out.println("Enter server port number: ");
      //port = kb.nextInt();
      
      //System.out.println("Enter host name");
      //String host = kb.nextLine();
   	  
      try{
    	
         cSock = new Socket(host,port);
         out = new PrintStream(cSock.getOutputStream());
         in = new DataInputStream(cSock.getInputStream());
         
         
      }
     
      
      
      catch(IOException e){
         System.err.println("Could not connet to: "+ host);
      }
      if(cSock != null && out != null && in != null){
         try{
        	 
        	
            mark= in.readLine();
            System.out.println(mark);
            out.println("done");
            
            
            new Thread(clientA).start();
            
            
            while(!closed){ //Chat receiver. 
            	
            }
            System.out.println("closed");
            out.close();
            in.close();
            cSock.close();
         }
         catch (IOException e) {
        	
            System.err.println("IOException:  " + e);
            System.exit(1);
         }
      	  
      }
      
   	   
   }
	

   @Override
   public void run() {
	   
	   if(mark.equals("X")){
		   opmark= "O";
	   }
	   else if(mark.equals("O")){
		   opmark = "X";
	   }
	   
	  
	  //System.out.println("run");
      area.setSize(800,400);
      area.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
     
      messages.setLayout(new GridLayout(1,1));
      window.setLayout(new GridLayout(3,3,3,3));
      area.setLayout(new GridLayout(1,1));
      messageArea.setBorder(LineBorder.createGrayLineBorder());
   	  messages.add(messageArea);
   	  //messageArea.setBackground(Color.BLUE);
   	  messageArea.setHorizontalAlignment(JLabel.CENTER);
      window.add(a);
      window.add(b);
      window.add(c);
      window.add(d);
      window.add(e);
      window.add(f);
      window.add(g);
      window.add(h);
      window.add(i);
      window.add(messages);
      //window.add(messageArea, "Center");
   	
   	
   	  
      area.setVisible(true);
   	
   	  //window.add(a.addActionListnener(new ActionListesner(){public void actionPerformed(ActionEvent e){JOptionPane.set()}}))
      a.addActionListener(this);
      b.addActionListener(this);
      c.addActionListener(this);
      d.addActionListener(this);
      e.addActionListener(this);
      f.addActionListener(this);
      g.addActionListener(this);
      h.addActionListener(this);
      i.addActionListener(this);
      area.add(window);
      area.add(messages,"Center");
      area.disable();
      messageArea.setText("Waiting for Opponent");
      boolean turn = false;
      
      
      String inputLine;
      
      
      try {
    	  
		while((inputLine = in.readLine())!= null){
			//System.out.println(inputLine);
			if(inputLine.equals("GO")){
				area.enable();
				messageArea.setText("Your turn "+mark);
			}
			else if(inputLine.equals("A")){
				 a.setText(opmark);
		         a.setEnabled(false);
		        out.println("done");
			}
			else if(inputLine.equals("B")){
				 b.setText(opmark);
		         b.setEnabled(false);
		         out.println("done");
			}
			else if(inputLine.equals("C")){
				 c.setText(opmark);
		         c.setEnabled(false);
		         out.println("done");
			}
			else if(inputLine.equals("D")){
				 d.setText(opmark);
		         d.setEnabled(false);
		         out.println("done");
			}
			else if(inputLine.equals("E")){
				 e.setText(opmark);
		         e.setEnabled(false);
		         out.println("done");
			}
			else if(inputLine.equals("F")){
				 f.setText(opmark);
		         f.setEnabled(false);
		         out.println("done");
			}
			else if(inputLine.equals("G")){
				 g.setText(opmark);
		         g.setEnabled(false);
		         out.println("done");
			}
			else if(inputLine.equals("H")){
				 h.setText(opmark);
		         h.setEnabled(false);
		         out.println("done");
			}
			else if(inputLine.equals("I")){
				 i.setText(opmark);
		         i.setEnabled(false);
		         out.println("done");
			}
			else if(inputLine.equals("Xwin")){
				 JOptionPane.showMessageDialog(null, "X Wins!");
		         area.enable();
		         area.dispose();
		         close();
			}
			else if(inputLine.equals("Owin")){
				JOptionPane.showMessageDialog(null, "O Wins!");
		         area.enable();
		         area.dispose();
		         close();
				
			}
			else if(inputLine.equals("tie")){
				JOptionPane.showMessageDialog(null, "Tie!");
		         area.enable();
		         area.dispose();
		         close();
			}
			//checkWinner();
		  
		  }
		
	} catch (IOException e1) {
		
		e1.printStackTrace();
		System.exit(1);
	}
      
      
      
   
      
   }
   private void close() throws IOException {
	  
	in.close();
	out.close();
	System.exit(1);
	
}



@Override
   public void actionPerformed(ActionEvent w) {
	
      if(w.getSource() ==a){
         a.setText(mark);
         //a.setBackground(Color.red);
         a.setEnabled(false);
         out.println("A");
      }
      else if(w.getSource()==b){
         b.setText(mark);
         b.setEnabled(false);
         out.println("B");
      }
      else if(w.getSource()==c){
         c.setText(mark);
         c.setEnabled(false);
         out.println("C");
      }
      else if(w.getSource()==d){
         d.setText(mark);
         d.setEnabled(false);
         out.println("D");
      }
      else if(w.getSource()==e){
         e.setText(mark);
         e.setEnabled(false);
         out.println("E");
      }
      else if(w.getSource()==f){
         f.setText(mark);
         f.setEnabled(false);
         out.println("F");
      }
      else if(w.getSource()==g){
         g.setText(mark);
         g.setEnabled(false);
         out.println("G");
      }
      else if(w.getSource()==h){
         h.setText(mark);
         h.setEnabled(false);
         out.println("H");
      }
      else if(w.getSource()==i){
         i.setText(mark);
         i.setEnabled(false);
         out.println("I");
      }
      
      area.disable();
      messageArea.setText("Waiting for Opponent");
      
      

   	
   	
   	
   }
}


