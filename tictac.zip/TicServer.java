import java.io.*;
import java.net.*;
import java.util.*;
import java.applet.*;
import java.awt.*;

import javax.swing.*;


public class TicServer {
	
   private static ServerSocket sSock = null;

   
   
   TicClient ty = new TicClient();
   /*
    * What to do.
    * 
    * clients needs to either hold player
    * 
    * 
    * 
    */
   
	
	
   public static void main(String[] args)throws Exception	{
      int port= 8080;
   	  
      try{
      	
         sSock= new ServerSocket(port);
         System.out.println("Server open on port: "+port);
      }
      catch (IOException e){
         System.out.println(e);
      }
   	
      newgame();
   	
   }
   public static void newgame(){
      while(true){
         try{
            Game game = new Game();
                //pair up players
            Game.Player[] clients = new Game.Player[2];
                
            clients[0]= game.new Player(sSock.accept(),'X');  
                 
            clients[1]= game.new Player(sSock.accept(),'O');
            Game.Play play = game.new Play(clients); 
                
            play.start();
                
         } 
         catch (IOException e){
            System.out.println(e);
         }
          	
          	
      }
   }
}

class Game {
	

   
   class Player{
      
      
      Socket sock;
      char mark; 
      PrintStream out;
      DataInputStream in;
      String inline;
      Player(){
        
      }
      public Player(Socket sock,char mark){
         this.sock = sock;
         this.mark = mark;
           
          
         
         try{
            this.in = new DataInputStream(sock.getInputStream());
            this.out = new PrintStream(sock.getOutputStream());
            out.println(mark);
            inline= in.readLine();
            System.out.println("Player made " + mark +" made");
            
         }
         catch(IOException e){
            System.out.println("Player gone");
         }
          	
      }
   }

	
	
	
   class Play extends Thread {
   	
      
      boolean win = false;
      int count=0;
      Player[] clients;
      
      int b[] = {0,0,0
       			,0,0,0
       			,0,0,0};
      public Play(){
        
       
      }
   	
      public Play(Player[] clients){
         this.clients = clients;
        
        
      }
      public String who(int i){
         if(i==-1){
            return "O";
         
         }
         else if(i==1)
            return "X";
         
		return null;
      	 
      }
   
      public boolean checkWin(){
         String r;
        //vertical
         if(b[0]==b[1]&& b[1]==b[2] && b[2]!=0){
            r = who(b[0]);
            clients[0].out.println(r+"win");
            clients[1].out.println(r+"win");
            return true;
         }
         else if(b[3]== b[4]&& b[4]== b[5] && b[5]!=0){
            r = who(b[3]);
            clients[0].out.println(r+"win");
            clients[1].out.println(r+"win");
            return true;
         }
         else if(b[6]== b[7]&& b[7]== b[8] && b[8]!=0){
            r = who(b[6]);
            clients[0].out.println(r+"win");
            clients[1].out.println(r+"win");
            return true;
         }//Horizontal
         else if(b[0]== b[3]&& b[3]== b[6] && b[6]!=0){
            r = who(b[0]);
            clients[0].out.println(r+"win");
            clients[1].out.println(r+"win");
            return true;
         }
         else if(b[1]== b[4]&& b[4]== b[7] && b[7]!=0){
            r = who(b[1]);
            clients[0].out.println(r+"win");
            clients[1].out.println(r+"win");
            return true;
         }
         else if(b[2]== b[5]&& b[5]== b[8] && b[8]!=0){
            r = who(b[2]);
            clients[0].out.println(r+"win");
            clients[1].out.println(r+"win");
            return true;
         }//cross
         else if(b[0]== b[4]&& b[4]== b[8] && b[8]!=0){
            r = who(b[0]);
            clients[0].out.println(r+"win");
            clients[1].out.println(r+"win");
            return true;
         }
         else if(b[6]== b[4]&& b[4]== b[2] && b[2]!=0){
            r = who(b[6]);
            clients[0].out.println(r+"win");
            clients[1].out.println(r+"win");
            return true;
         }
         else if(count==9){
            clients[0].out.println("tie");
            clients[1].out.println("tie");
         }
         return false;
        
        
      }
      
      public void processMove(String i){
         count++;
         if(i.equals("XA")){
            b[0]= 1;		        
         }
         else if(i.equals("OA")){
            b[0]= -1;		        
         }
         else if(i.equals("XB")){
            b[1]= 1;		        
         }
         else if(i.equals("OB")){
            b[1]= -1;		        
         }
         else if(i.equals("XC")){
            b[2]= 1; 
         }
         else if(i.equals("OC")){
            b[2]= -1;		        
         }
         else if(i.equals("XD")){
            b[3]= 1;		        
         }
         else if(i.equals("OD")){
            b[3]= -1;
         }
         else if(i.equals("XE")){
            b[4]= 1;		        
         }
         else if(i.equals("OE")){
            b[4]= -1;	   
         }
         else if(i.equals("OF")){
            b[5]= -1;
         }
         else if(i.equals("XF")){
            b[5]= 1;		        
         }
         else if(i.equals("OG")){
            b[6]= -1;
         }
         else if(i.equals("XG")){
            b[6]= 1;		        
         }
         else if(i.equals("XH")){
            b[7]= 1;		        
         }
         else if(i.equals("OH")){
            b[7]= -1;
         }
         else if(i.equals("OI")){
            b[8]= -1;
         }
         else if(i.equals("XI")){
            b[8]= 1;		        
         }
      }
      	
   
   	
      public void run(){
         System.out.println("Game has started");
         int i;
         String inputLine;
         String com;
      
      	
         try {
         
         	
            while(!win){//play game
            	
               clients[0].out.println("GO");
               inputLine= clients[0].in.readLine();           			
               clients[1].out.println(inputLine);
               com =clients[1].in.readLine();
               inputLine = clients[0].mark+inputLine;
               processMove(inputLine);
               
               if(checkWin()){
                  break;}
               clients[1].out.println("GO");
               inputLine= clients[1].in.readLine();
               clients[0].out.println(inputLine);
               com =clients[0].in.readLine();
               inputLine = clients[1].mark+inputLine;
               processMove(inputLine);
               
               if(checkWin()){
                  break;}
            			
            		
            }
         		
         } 
         catch (IOException e) {
         		
            System.err.println("Player Left.");
            for(i=0;i<=1;i++){
               try {
                  clients[i].in.close();
               
                  clients[i].out.close();
               
               } 
               catch (IOException e1) {
               
                  e1.printStackTrace();
               }
            }
         }
         finally{
            for(i=0;i<=1;i++){
               try {
                  clients[i].in.close();
               
                  clients[i].out.close();
               
               } 
               catch (IOException e1) {
               
               //e1.printStackTrace();
               }
            }
         }
      	
      		
      }
   	
   }






}